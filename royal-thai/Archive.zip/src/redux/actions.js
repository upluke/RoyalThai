export const getItemsByCategories=()=>{
    return {
        type:'GETITEMSBYCATEGORIES'
    }
}