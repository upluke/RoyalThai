export const categories=['Appetizers','Soups', 'Noodle Soups', 'Salads', 'Noodle Plates']
export const MENU_DATA =[
            {
                id:"Sampler for 2",
                name:'Sampler for 2',
                price: 13.35,
                description: 'Sampler plate of Fried shumai, crab Rangoon, pot sticker and chicken egg rolls.',
                category:'Appetizers',
            },
            {
                id:'Fresh Spring Rolls',
                name:'Fresh Spring Rolls',
                price: 5.95,
                description:'Fresh spring rolls stuffed with tofu, egg, cucumber and bean sprout topped with tamarind sauce.',
                category:'Appetizers',
            },
            {
                id:'Peanut Sauce Spring Rolls',
                name:'Peanut Sauce Spring Rolls',
                price: 5.95,
                description:'Fresh spring rolls stuffed with tofu, egg, cucumber and bean sprout topped with peanut sauce.',
                category:'Appetizers',
            },
            {
                id:'Tom Yum (Large)',
                name:'Tom Yum (Large)',
                price: 9.95,
                description: 'Sampler plate of Fried shumai, crab Rangoon, pot sticker and chicken egg rolls.',
                category:'Soups',
            },
            {
                id:'Tom Kha (Large)',
                name:'Tom Kha (Large)',
                price: 5.95,
                description:'Tasty coconut milk soup with sliced mushrooms, lemongrass, cilantro and lime juice. Choice of chicken, tofu or vegetable.',
                category:'Soups',
            },
            {
                id:'Spinach Soup',
                name:'Spinach Soup',
                price: 7.95,
                description:'Fresh spinach in clear broth.',
                category:'Soups',
            },
            {
                id:'Thai noodle soup',
                name:'Thai noodle soup',
                price: 9.95,
                description: 'Thin rice noodle in clear broth with bean sprout, fried garlic, scallion and cilantro. Choice of chicken, beef, pork or tofu.',
                category:'Noodle Soups',
            },
            {
                id:'Thai boat noodle soup',
                name:'Thai boat noodle soup',
                price: 12.95,
                description:'Thin rice noodle, bean sprout, Chinese broccoli and slice tender beef in beef broth.',
                category:'Noodle Soups',
            },
            {
                id:'Kow soy',
                name:'Kow soy',
                price: 11.95,
                description:'Ramen noodle in a yellow curry broth served with lime and red onion. Choice of chicken, beef, pork, tofu or vegetable.',
                category:'Noodle Soups',
            },
            {
                id:'Cucumber Salad',
                name:'Cucumber Salad',
                price: 5.50,
                description: 'Fresh cucumber topped with red onion, carrot, and sweet vinegar dressing.',
                category:'Salads',
            },
            {
                id:'Yum Nua',
                name:'Yum Nua',
                price: 10.95,
                description:'Pan-Seared beef, tomato, cucumber and red onion on bed of lettuce with lemon juice dressing.',
                category:'Salads',
            },
            {
                id:'Larb',
                name:'Larb',
                price: 9.95,
                description:'Ground chicken, red onion, mint, green onion, cilantro and roasted rice powder with Thai lime dressing.',
                category:'Salads',
            },
            {
                id:'Royal Thai noodle',
                name:'Royal Thai noodle',
                price: 12.95,
                description: 'Crispy wide rice noodle topped with bok choy, bamboo shoot, mushroom, baby corn, onion, carrot and peapod in our house special sauce.',
                category:'Noodle Plates',
            },
            {
                id:'Seafood royal Thai noodle',
                name:'Seafood royal Thai noodle',
                price: 14.95,
                description:'Crispy wide rice noodle topped with shrimp, scallop, squid, bok choy, bamboo shoot, mushroom, baby corn, onion, carrot and peapod in our house special sauce.',
                category:'Noodle Plates',
            },
            {
                id:'Pad Thai',
                name:'Pad Thai',
                price: 10.95,
                description:'Thin rice noodle stir-fried with choice of meat, egg, tofu, bean sprout, green chive, and crushed peanut.',
                category:'Noodle Plates',
            }
    

 

]